import { JudgeStatus } from './judge-status';

describe('JudgeStatus', () => {
  it('should create an instance', () => {
    expect(new JudgeStatus()).toBeTruthy();
  });
});
