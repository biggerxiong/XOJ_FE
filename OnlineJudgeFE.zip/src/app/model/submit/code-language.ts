export class CodeLanguage {

    constructor(
        public value: number,
        public name: string
    ) {}
}
