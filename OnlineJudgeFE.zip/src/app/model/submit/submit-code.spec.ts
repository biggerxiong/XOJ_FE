import { SubmitCode } from './submit-code';

describe('SubmitCode', () => {
  it('should create an instance', () => {
    expect(new SubmitCode()).toBeTruthy();
  });
});
