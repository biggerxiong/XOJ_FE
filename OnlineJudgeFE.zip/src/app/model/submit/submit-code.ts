export class SubmitCode {

    constructor(
        public language: number,
        public source: string,
        public problemId: number
    ) {}
}
