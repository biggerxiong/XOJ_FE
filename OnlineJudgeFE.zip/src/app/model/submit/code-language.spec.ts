import { CodeLanguage } from './code-language';

describe('CodeLanguage', () => {
  it('should create an instance', () => {
    expect(new CodeLanguage()).toBeTruthy();
  });
});
