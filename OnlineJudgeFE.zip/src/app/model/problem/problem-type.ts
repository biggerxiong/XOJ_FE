export class ProblemType {

    problemTypeId: number
    problemTypeName: string
    problemTypeDescription: string

    constructor(){}
}
