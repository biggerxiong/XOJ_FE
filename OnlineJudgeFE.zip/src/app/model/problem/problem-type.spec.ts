import { ProblemType } from './problem-type';

describe('ProblemType', () => {
  it('should create an instance', () => {
    expect(new ProblemType()).toBeTruthy();
  });
});
