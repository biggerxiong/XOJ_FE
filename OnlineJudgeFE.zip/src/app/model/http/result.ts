export class Result {

    code: number
    msg: string
    data: any

    constructor(){}

}
