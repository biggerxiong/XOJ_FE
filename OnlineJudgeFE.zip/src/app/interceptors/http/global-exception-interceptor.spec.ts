import { GlobalExceptionInterceptor } from './global-exception-interceptor';

describe('GlobalExceptionInterceptor', () => {
  it('should create an instance', () => {
    expect(new GlobalExceptionInterceptor()).toBeTruthy();
  });
});
